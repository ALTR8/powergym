<?php
return[
    /*
    |--------------------------------------------------------------------------
    | Register Post Type And Taxonomies
    |--------------------------------------------------------------------------
    |
    | Configuring args of post types
    |
    */
    'post_types' => array(
        'listing'       => array(
            'description'        => esc_html__( 'Description.', 'wiloke' ),
            'public'             => true,
            'menu_icon'          => 'dashicons-admin-site',
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'show_in_rest'       => true,
            'rest_base'          => 'listings',
            'rest_controller_class' => 'WP_REST_Posts_Controller',
            'rewrite'            => array( 'slug' => 'listing', 'with_front' => false),
            'capabilities'       => array(
	            'edit_post'         => 'edit_listing',
	            'edit_posts'        => 'edit_listings',
	            'edit_others_posts' => 'edit_other_listings',
	            'publish_posts'     => 'publish_listings',
	            'read_post'         => 'read_listing',
	            'read_private_posts'=> 'read_private_listings',
	            'delete_post'       => 'delete_listing'
            ),
            'map_meta_cap'   => true,
            'has_archive'    => true,
            'hierarchical'   => false,
            'menu_position'  => null,
            'supports'      => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments', 'custom-fields', 'page-attributes' )
        ),
        'claim'       => array(
	        'description'        => esc_html__( 'Description.', 'wiloke' ),
	        'public'             => false,
	        'menu_icon'          => 'dashicons-format-status',
	        'publicly_queryable' => false,
	        'show_ui'            => true,
	        'show_in_menu'       => true,
	        'query_var'          => true,
	        'show_in_rest'       => true,
	        'rest_base'          => 'claims',
	        'rest_controller_class' => 'WP_REST_Posts_Controller',
	        'rewrite'            => array( 'slug' => 'claim', 'with_front' => false),
	        'map_meta_cap'   => true,
	        'has_archive'    => false,
	        'hierarchical'   => false,
	        'menu_position'  => null,
	        'supports'      => array('title')
        ),
        'testimonial'   => array(
	        'description'        => esc_html__( 'Description.', 'wiloke' ),
	        'public'             => true,
	        'menu_icon'          => 'dashicons-testimonial',
	        'publicly_queryable' => true,
	        'show_ui'            => true,
	        'show_in_menu'       => true,
	        'query_var'          => true,
	        'show_in_rest'       => true,
	        'exclude_from_search'=> true,
	        'rest_base'          => 'testimonials',
	        'rest_controller_class' => 'WP_REST_Posts_Controller',
	        'rewrite'            => array( 'slug' => 'testimonial', 'with_front' => false),
	        'capability_type'    => 'post',
	        'has_archive'        => true,
	        'hierarchical'       => false,
	        'menu_position'      => null,
	        'supports'           => array( 'title', 'editor' )
        ),
        'event'         => array(
	        'description'        => esc_html__( 'Description.', 'wiloke' ),
	        'public'             => true,
	        'menu_icon'          => 'dashicons-megaphone',
	        'publicly_queryable' => true,
	        'show_ui'            => true,
	        'show_in_menu'       => true,
	        'query_var'          => true,
	        'show_in_rest'       => true,
	        'rest_base'          => 'events',
	        'rest_controller_class' => 'WP_REST_Posts_Controller',
	        'rewrite'            => array( 'slug' => 'event', 'with_front' => false),
	        'capability_type'    => 'post',
	        'has_archive'        => true,
	        'hierarchical'       => false,
	        'menu_position'      => null,
	        'supports'           => array( 'title', 'editor', 'thumbnail', 'page-attributes' )
        ),
	    'pricing'       => array(
		    'description'        => esc_html__( 'Description.', 'wiloke' ),
		    'public'             => true,
		    'menu_icon'          => 'dashicons-sos',
		    'publicly_queryable' => true,
		    'exclude_from_search'=> true,
		    'show_ui'            => true,
		    'show_in_menu'       => true,
		    'query_var'          => true,
		    'show_in_rest'       => true,
		    'rest_base'          => 'pricings',
		    'rest_controller_class' => 'WP_REST_Posts_Controller',
		    'rewrite'            => array( 'slug' => 'pricing', 'with_front' => false),
		    'capability_type'    => 'post',
		    'has_archive'        => true,
		    'hierarchical'       => false,
		    'menu_position'      => null,
		    'supports'           => array( 'title', 'editor', 'thumbnail' )
	    ),
        'event-pricing'       => array(
	        'description'        => esc_html__( 'Description.', 'wiloke' ),
	        'public'             => true,
	        'menu_icon'          => 'dashicons-sos',
	        'publicly_queryable' => true,
	        'exclude_from_search'=> true,
	        'show_ui'            => true,
	        'show_in_menu'       => true,
	        'query_var'          => true,
	        'show_in_rest'       => true,
	        'rest_base'          => 'event-pricings',
	        'rest_controller_class' => 'WP_REST_Posts_Controller',
	        'rewrite'            => array( 'slug' => 'event-pricing', 'with_front' => false),
	        'capability_type'    => 'post',
	        'has_archive'        => true,
	        'hierarchical'       => false,
	        'menu_position'      => null,
	        'supports'           => array( 'title', 'editor', 'page-attributes' )
        ),
        'review'        => array(
	        'description'        => esc_html__( 'Description.', 'wiloke' ),
	        'public'             => true,
	        'menu_icon'          => 'dashicons-format-chat',
	        'publicly_queryable' => true,
	        'show_ui'            => true,
	        'show_in_menu'       => true,
	        'exclude_from_search'=> true,
	        'query_var'          => true,
	        'show_in_rest'       => true,
	        'rest_base'          => 'reviews',
	        'rest_controller_class' => 'WP_REST_Posts_Controller',
	        'rewrite'            => array( 'slug' => 'review', 'with_front' => false),
	        'capability_type'    => 'post',
	        'has_archive'        => true,
	        'hierarchical'       => false,
	        'menu_position'      => null,
	        'supports'           => array('title', 'editor')
        ),
    ),
    'taxonomies' => array(
        'listing_location' => array(
            'hierarchical'      => true,
            'show_ui'               => true,
            'show_in_rest'          => true,
            'rest_base'             => 'listing_location',
            'rest_controller_class' => 'WP_REST_Terms_Controller',
            'show_admin_column'     => true,
            'query_var'             => true,
            'rewrite'               => array('slug' => 'listing-location'),
            'post_types'            => array('listing')
        ),
        'listing_cat' => array(
            'hierarchical'      => true,
            'show_ui'               => true,
            'show_admin_column'     => true,
            'show_in_rest'          => true,
            'rest_base'             => 'listing_cat',
            'rest_controller_class' => 'WP_REST_Terms_Controller',
            'query_var'             => true,
            'rewrite'               => array('slug' => 'listing-cat'),
            'post_types'            => array('listing')
        ),
        'listing_tag' => array(
	        'hierarchical'      => false,
	        'show_ui'               => true,
	        'show_admin_column'     => true,
	        'show_in_rest'          => true,
	        'rest_base'             => 'listing_tag',
	        'rest_controller_class' => 'WP_REST_Terms_Controller',
	        'query_var'             => true,
	        'rewrite'               => array('slug' => 'listing-tag'),
	        'post_types'            => array('listing')
        )
    ),
	'post_statuses'=> array(
		'processing' => array(
			'label'                     => esc_html__( 'Unpaid', 'wiloke' ),
			'public'                    => false,
			'exclude_from_search'       => true,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'private'                   => true,
			'label_count'               => _n_noop( 'Unpaid <span class="count">(%s)</span>', 'Unpaid <span class="count">(%s)</span>', 'wiloke' ),
		),
		'expired' => array(
			'label'                     => esc_html__( 'Expired', 'wiloke' ),
			'public'                    => false,
			'private'                   => true,
			'exclude_from_search'       => true,
			'show_in_admin_all_list'    => false,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Expired <span class="count">(%s)</span>', 'Expired <span class="count">(%s)</span>', 'wiloke' ),
		),
		'renew' => array(
			'label'                     => esc_html__( 'Renew', 'wiloke' ),
			'public'                    => false,
			'exclude_from_search'       => true,
			'private'                   => true,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Renew <span class="count">(%s)</span>', 'Renew <span class="count">(%s)</span>', 'wiloke' ),
		),
		'temporary_closed' => array(
			'label'                     => esc_html__( 'Temporary Closed', 'wiloke' ),
			'public'                    => false,
			'protected'                 => true,
			'exclude_from_search'       => true,
			'private'                   => true,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Temporary closed <span class="count">(%s)</span>', 'Temporary closed <span class="count">(%s)</span>', 'wiloke' ),
		)
	),
	'settings'   => array(
		'submission' => array(
			'fields' => array(
				array(
					'type' => 'open_segment'
				),
				array(
					'text'    => esc_html__('General Settings', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'select',
					'heading' => esc_html__('Toggle Wiloke Submission', 'wiloke'),
					'desc'    => esc_html__('Ensure that the New User Default Role has been set to Wiloke Submission: Settings -> General -> New User Default Role', 'wiloke'),
					'name'    => 'wiloke_listgo[toggle]',
					'id'      => 'wiloke_listgo_toggle',
					'options' => array(
						'disable' => esc_html__('Disable', 'wiloke'),
						'enable'  => esc_html__('Enable', 'wiloke'),
					),
					'default'     => 'disable'
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Your Brand (*)', 'wiloke'),
					'description' => esc_html__('The brand name will be shown on the PayPal payment page and it also used as Email Subject.', 'wiloke'),
					'desc_status'=>'info',
					'name'    => 'wiloke_listgo[brandname]',
					'id'      => 'branding',
					'default' => 'Wiloke'
				),
				array(
					'type'    => 'select',
					'heading' => esc_html__('Approved Method', 'wiloke'),
					'name'    => 'wiloke_listgo[approved_method]',
					'desc'    => esc_html__('What method is used to review?', 'wiloke'),
					'desc_status'=>'info',
					'id'      => 'approved_method',
					'default' => 'manual_review',
					'options' => array(
						'manual_review' => esc_html__('Manual Review', 'wiloke'),
						'auto_approved_after_payment' => esc_html__('Automatically Approval After Payment Success', 'wiloke'),
					)
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Automatically Delete Unpaid Listing', 'wiloke'),
					'desc'    => esc_html__('A robot will automatically check all unpaid listings each day, and if a listing has been submitted more than x hours, it will be deleted. Leave empty to disable this feature.', 'wiloke'),
					'desc_status'=>'info',
					'name'    => 'wiloke_listgo[delete_listing_conditional]',
					'id'      => 'delete_listing_conditional',
					'default' => 60
				),
				array(
					'type'    => 'select',
					'heading' => esc_html__('Edit Published Listing Type', 'wiloke'),
					'name'    => 'wiloke_listgo[published_listing_editable]',
					'desc'    => esc_html__('Allow / Not allow editing a listing that has been published', 'wiloke'),
					'desc_status'=>'info',
					'id'      => 'published_listing_editable',
					'default' => 'disable',
					'options' => array(
						'allow_need_review'     => esc_html__('Editable and Need to review before re-publishing', 'wiloke'),
						'allow_trust_approved'  => esc_html__('Editable and immediately approved', 'wiloke'),
						'not_allow'             => esc_html__('Not allow editing', 'wiloke'),
					)
				),
				array(
					'type' => 'close_segment'
				),
				array(
					'type'    => 'open_segment',
					'class'   => ''
				),
				array(
					'text'    => esc_html__('Payment General Settings (*)', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'select',
					'heading' => esc_html__('Mode', 'wiloke'),
					'name'    => 'wiloke_listgo[mode]',
					'id'      => 'payment_mode',
					'options' => array(
						'sandbox' => esc_html__('Sandbox', 'wiloke'),
						'live'    => esc_html__('Live', 'wiloke')
					),
					'default' => 'sandbox'
				),
				array(
					'type'    => 'select',
					'heading' => esc_html__('Currency Code', 'wiloke'),
					'name'    => 'wiloke_listgo[currency_code]',
					'id'      => 'paypal_mode',
					'options' => array(
						'AUD' => 'AUD',
						'BRL' => 'BRL',
						'USD' => 'USD',
						'CAD' => 'CAD',
						'CZK' => 'CZK',
						'DKK' => 'DKK',
						'EUR' => 'EUR',
						'GTQ' => 'GTQ',
						'HKD' => 'HKD',
						'HUF' => 'HUF',
						'ILS' => 'ILS',
						'JPY' => 'JPY',
						'MYR' => 'MYR',
						'MXN' => 'MXN',
						'NOK' => 'NOK',
						'NZD' => 'NZD',
						'PHP' => 'PHP',
						'PLN' => 'PLN',
						'GBP' => 'GBP',
						'RUB' => 'RUB',
						'SGD' => 'SGD',
						'SEK' => 'SEK',
						'CHF' => 'CHF',
						'TWD' => 'TWD',
						'THB' => 'THB',
						'INR' => 'INR',
						'KWD' => 'KWD',
						'PEN' => 'PEN',
						'SAR' => 'SAR',
						'ZAR' => 'ZAR',
						'TRY' => 'TRY',
						'AED' => 'AED',
						'LKR' => 'LKR',
						'IDR' => 'IDR'
					),
					'default' => 'USD'
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Maximum Failed Payments (PayPal)', 'wiloke'),
					'name'    => 'wiloke_listgo[maxFailedPayments]',
					'id'      => 'maxFailedPayments',
					'default' => 3,
					'desc'    => esc_html__('Number of scheduled payments that can fail before the profile is automatically suspended.', 'wiloke'),
					'desc_status'=>'info'
				),
				array(
					'type'    => 'select',
					'heading' => esc_html__('Currency position', 'wiloke'),
					'name'    => 'wiloke_listgo[currency_position]',
					'id'      => 'currency_position',
					'options' => array(
						'left'          => esc_html__('Left $99.99', 'wiloke'),
						'right'         => esc_html__('Right 99.99$', 'wiloke'),
						'left_space'    => esc_html__('Left With Space $ 99.99', 'wiloke'),
						'right_space'   => esc_html__('Right With Space 99.99 $', 'wiloke'),
					),
					'default' => 'left'
				),
				array(
					'text'    => esc_html__('Payment gateways', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'select_ui',
					'heading' => esc_html__('Accept Payment Via', 'wiloke'),
					'name'    => 'wiloke_listgo[payment_gateways]',
					'id'      => 'payment_gateways',
					'multiple'=>true,
					'desc'    => esc_html__('Notice: Check Payment is not available for Recurring Payments'),
					'desc_status'=>'info',
					'default' => 'paypal',
//					'default' => 'paypal,stripe',
					'options' => array(
						array(
							'value' => 'paypal',
							'text'  => esc_html__('PayPal', 'wiloke'),
							'img'   => plugin_dir_url(dirname(__FILE__)) . 'admin/img/paypal.png'
						),
						array(
							'value' => '2checkout',
							'text'  => esc_html__('Credit Card (2Checkout)', 'wiloke'),
							'img'   => plugin_dir_url(dirname(__FILE__)) . 'admin/img/paypal.png'
						),
//						array(
//							'value' => 'stripe',
//							'text'  => esc_html__('Stripe', 'wiloke'),
//							'img'   => plugin_dir_url(dirname(__FILE__)) . 'admin/img/checkpayment.png'
//						),
//						array(
//							'value' => 'banktransfer',
//							'text'  => esc_html__('Direct Bank Tranfer', 'wiloke'),
//							'img'   => plugin_dir_url(dirname(__FILE__)) . 'admin/img/bank-transfer.png'
//						),
						array(
							'value' => 'checkpayment',
							'text'  => esc_html__('Check Payment', 'wiloke'),
							'img'   => plugin_dir_url(dirname(__FILE__)) . 'admin/img/checkpayment.png'
						)
					)
				),
				array(
					'type'    => 'select',
					'heading' => esc_html__('Billing Type *', 'wiloke'),
					'name'    => 'wiloke_listgo[billing_type]',
					'id'      => 'wiloke_listgo_billing_type',
					'options' => array(
						'None'               => esc_html__('Non-Recurring Payments', 'wiloke'),
						'RecurringPayments'  => esc_html__('Recurring Payments', 'wiloke'),
					),
					'default'     => 'default'
				),
				array(
					'type'    => 'close_segment'
				),
				array(
					'type'    => 'open_segment'
				),
				array(
					'text'    => esc_html__('PayPal Live', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('User Name', 'wiloke'),
					'name'    => 'wiloke_listgo[live_username]',
					'id'      => 'paypal_live_username',
					'default' => ''
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Password', 'wiloke'),
					'name'    => 'wiloke_listgo[live_password]',
					'id'      => 'paypal_live_password',
					'default' => ''
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Signature', 'wiloke'),
					'name'    => 'wiloke_listgo[live_signature]',
					'id'      => 'paypal_live_signature',
					'default' => ''
				),
				array(
					'text'    => esc_html__('PayPal Sandbox', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('User Name', 'wiloke'),
					'name'    => 'wiloke_listgo[sandbox_username]',
					'id'      => 'paypal_sandbox_username',
					'default' => 'wiloketestcaicoi_api2.gmail.com'
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Password', 'wiloke'),
					'name'    => 'wiloke_listgo[sandbox_password]',
					'id'      => 'paypal_sandbox_password',
					'default' => 'NCAK8DBVRVVXMDU6'
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Signature', 'wiloke'),
					'name'    => 'wiloke_listgo[sandbox_signature]',
					'id'      => 'paypal_sandbox_signature',
					'default' => 'AFcWxV21C7fd0v3bYYYRCpSSRl31AflEhbVAZs8zfPDpEzg8nYbKKntH'
				),
				array(
					'type'    => 'close_segment'
				),
				array(
					'type'    => 'open_segment'
				),
				array(
					'text'    => esc_html__('2Checkout General Settings *', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'desc',
					'desc'   => __('Important: You have to follow step by step in this tutorial <a href="https://blog.wiloke.com/recurring-payments-2checkout-gateway-configuration/" target="_blank">RECURRING PAYMENTS – 2CHECKOUT GATEWAY CONFIGURATION</a> to complete the settings.', 'wiloke'),
					'desc_status' => 'error visible'
				),
				array(
					'type'    => 'select',
					'heading' => esc_html__('Auto Refund After Your Customer Changed Their Plan', 'wiloke'),
					'desc_status' => 'info',
					'name'    => 'wiloke_listgo[2checkout_auto_refund]',
					'id'      => '2checkout_auto_refund',
					'default' => 'disable',
					'options' => array(
						'disable' => esc_html__('Disable', 'wiloke'),
						'enable'  => esc_html__('Enable', 'wiloke')
					),
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Secret Word *', 'wiloke'),
					'desc'    => __('<a href="http://help.2checkout.com/articles/FAQ/Where-do-I-set-up-the-Secret-Word/" target="_blank">Where do I set up the Secret Word?</a>', 'wiloke'),
					'desc_status' => 'info',
					'name'    => 'wiloke_listgo[2checkout_secret_word]',
					'id'      => '2checkout_secret_word',
					'default' => ''
				),
				array(
					'text'    => esc_html__('2Checkout Instant Notification Service (INS) *', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'desc',
					'desc'   => __('2Checkout\'s Instant Notification Service allows 2Checkout to communicate with your store, keeping transaction data in sync. INS must be set up properly for recurring billing to work. From your 2Checkout account, navigate to the <a href="https://www.2checkout.com/va/notifications/" target="_blank">Notifications</a> screen and enable all notifications.', 'wiloke'),
					'desc_status' => 'info'
				),
				array(
					'type'    => 'desc',
					'desc'   => __('The URL should be set to: http://example.com/?wiloke-submission-listener=2Checkout. Note: please replace "example.com" with the appropriate name of your website.', 'wiloke'),
					'desc_status' => 'warning visible'
				),
				array(
					'type'    => 'desc',
					'desc'   => esc_html__('Important! If INS is not properly configured, subscription tracking will not work.', 'wiloke'),
					'desc_status' => 'error visible'
				),
				array(
					'text'    => esc_html__('2Checkout Username and Password', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'desc',
					'desc'   => __('Please read this tutorial <a href="https://blog.wiloke.com/recurring-payments-2checkout-gateway-configuration/" target="_blank">RECURRING PAYMENTS – 2CHECKOUT GATEWAY CONFIGURATION</a> to know how to configure your 2Checkout Username and Password', 'wiloke'),
					'desc_status' => 'warning visible'
				),
				array(
					'text'    => esc_html__('2Checkout Sandbox', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Seller ID (*)', 'wiloke'),
					'desc'    => __('<a href="http://help.2checkout.com/articles/FAQ/Where-is-my-Seller-ID" target="_blank">Where is my Seller ID?</a>'),
					'desc_status' => 'info',
					'name'    => 'wiloke_listgo[2co_sandbox_seller_id]',
					'id'      => '2co_sandbox_seller_id',
					'default' => ''
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Publishable Key (*)', 'wiloke'),
					'name'    => 'wiloke_listgo[2co_sandbox_publishable_key]',
					'id'      => '2co_sandbox_publishablekey',
					'default' => ''
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Private Key (*)', 'wiloke'),
					'name'    => 'wiloke_listgo[2co_sandbox_private_key]',
					'id'      => '2co_sandbox_private_key',
					'default' => ''
				),
				array(
					'text'    => esc_html__('2Checkout Live', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Seller ID (*)', 'wiloke'),
					'desc'    => __('<a href="http://help.2checkout.com/articles/FAQ/Where-is-my-Seller-ID" target="_blank">Where is my Seller ID?</a>'),
					'desc_status' => 'info',
					'name'    => 'wiloke_listgo[2co_live_seller_id]',
					'id'      => '2co_live_seller_id',
					'default' => ''
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Publishable Key (*)', 'wiloke'),
					'name'    => 'wiloke_listgo[2co_live_publishable_key]',
					'id'      => '2co_live_publishablekey',
					'default' => ''
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Private Key (*)', 'wiloke'),
					'name'    => 'wiloke_listgo[2co_live_private_key]',
					'id'      => '2co_live_private_key',
					'default' => ''
				),
				array(
					'type'    => 'close_segment'
				),
//				array(
//					'type'    => 'open_segment'
//				),
//				array(
//					'heading' => esc_html__('Zero-decimal Currency *', 'wiloke'),
//					'type'    => 'text',
//					'name'    => 'wiloke_listgo[stripe_zero_decimal]',
//					'id'      => 'stripe_sandbox_secret_key',
//					'desc'    => esc_html__('Stripe expects amounts to be provided in a currency’s smallest unit. For example, Plan A\'s cost $10 USD, We need to provide an amount value of 10*100 = 1000 (i.e, 1000 cents), so you should enter 100 in this setting. But in case, you are using JPY currency, because there is no decimal for JPY so ¥1 is the smallest currency unit, since you should enter 1 in this setting.', 'wiloke'),
//					'desc_status'=>'info',
//					'default' => 100
//				),
//				array(
//					'text'    => esc_html__('Stripe API', 'wiloke'),
//					'type'    => 'header',
//					'class'   => 'dividing',
//					'tag'     => 'h3'
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Publishable Key (*)', 'wiloke'),
//					'name'    => 'wiloke_listgo[stripe_publishable_key]',
//					'id'      => 'stripe_publishable_key',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Secret Key (*)', 'wiloke'),
//					'name'    => 'wiloke_listgo[stripe_secret_key]',
//					'id'      => 'stripe_secret_key',
//					'default' => ''
//				),
//				array(
//					'type'    => 'close_segment'
//				),
//				array(
//					'type'    => 'open_segment'
//				),
//				array(
//					'text'    => esc_html__('Direct Bank Transfer', 'wiloke'),
//					'type'    => 'header',
//					'class'   => 'dividing',
//					'tag'     => 'h3'
//				),
//				array(
//					'type'    => 'open_fields_group',
//					'class'   => 'six'
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Account Name 1', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][account_name][1]',
//					'id'      => 'bank_transfer_account_name_1',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Account Number 1', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][account_number][1]',
//					'id'      => 'bank_transfer_account_number_1',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Bank Name 1', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][name][1]',
//					'id'      => 'bank_transfer_name_1',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Short code 1', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][short_code][1]',
//					'id'      => 'bank_transfer_short_code_1',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('IBAN 1', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][iban][1]',
//					'id'      => 'bank_transfer_iban_1',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('BIC / Swift 1', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][swift][1]',
//					'id'      => 'bank_transfer_swift_1',
//					'default' => ''
//				),
//				array(
//					'type'    => 'close'
//				),
//				array(
//					'type'    => 'open_fields_group',
//					'class'   => 'six'
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Account Name 2', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][account_name][2]',
//					'id'      => 'bank_transfer_account_name_2',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Account Number 2', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][account_number][2]',
//					'id'      => 'bank_transfer_account_number_2',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Bank Name 2', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][name][2]',
//					'id'      => 'bank_transfer_name_2',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Short code 2', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][short_code][2]',
//					'id'      => 'bank_transfer_short_code_2',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('IBAN 2', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][iban][2]',
//					'id'      => 'bank_transfer_iban_2',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('BIC / Swift 2', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][swift][2]',
//					'id'      => 'bank_transfer_swift_2',
//					'default' => ''
//				),
//				array(
//					'type'    => 'close'
//				),
//				array(
//					'type'    => 'open_fields_group',
//					'class'   => 'six'
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Account Name 3', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][account_name][3]',
//					'id'      => 'bank_transfer_account_name_3',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Account Number 3', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][account_number][3]',
//					'id'      => 'bank_transfer_account_number_3',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Bank Name 3', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][name][3]',
//					'id'      => 'bank_transfer_name_3',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Short code 3', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][short_code][3]',
//					'id'      => 'bank_transfer_short_code_3',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('IBAN 3', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][iban][3]',
//					'id'      => 'bank_transfer_iban_3',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('BIC / Swift 3', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][swift][3]',
//					'id'      => 'bank_transfer_swift_3',
//					'default' => ''
//				),
//				array(
//					'type'    => 'close'
//				),
//				array(
//					'type'    => 'open_fields_group',
//					'class'   => 'six'
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Account Name 4', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][account_name][4]',
//					'id'      => 'bank_transfer_account_name_4',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Account Number 4', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][account_number][4]',
//					'id'      => 'bank_transfer_account_number_4',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Bank Name 4', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][name][4]',
//					'id'      => 'bank_transfer_name_4',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('Short code 4', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][short_code][4]',
//					'id'      => 'bank_transfer_short_code_4',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('IBAN 4', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][iban][4]',
//					'id'      => 'bank_transfer_iban_4',
//					'default' => ''
//				),
//				array(
//					'type'    => 'text',
//					'heading' => esc_html__('BIC / Swift 4', 'wiloke'),
//					'name'    => 'wiloke_listgo[bank_transfer][swift][4]',
//					'id'      => 'bank_transfer_swift_4',
//					'default' => ''
//				),
//				array(
//					'type'    => 'close'
//				),
//				array(
//					'type'    => 'close_segment'
//				),
				array(
					'type'    => 'open_segment'
				),
				array(
					'text'    => esc_html__('Payment Pages (*)', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'select_post',
					'heading' => esc_html__('Package page', 'wiloke'),
					'desc'    => esc_html__('Set the package leads to Pricing table. Please click on Wiloke Guide -> FAQs -> Setup Package page to know more.', 'wiloke'),
					'desc_status'=>'info',
					'name'    => 'wiloke_listgo[package]',
					'id'      => 'paypal_packagepage',
					'post_type'=>'page',
					'default' => ''
				),
				array(
					'type'    => 'select_post',
					'heading' => esc_html__('Customer Plans*', 'wiloke'),
					'desc'    => esc_html__(' Deciding what plans will be shown on the Package page. Notice: From ListGo 1.0.9, We moved Custom Plans to Wiloke Submission place. This setting in Packages shortcode is no longer available.', 'wiloke'),
					'desc_status'=>'info',
					'name'    => 'wiloke_listgo[customer_plans]',
					'id'      => '',
					'multiple'=>true,
					'post_type'=>'pricing',
					'default' => ''
				),
//				array(
//					'type'    => 'select_post',
//					'heading' => esc_html__('Update Term Link', 'wiloke'),
//					'desc'    => esc_html__('Adding the Term and Conditional url below the Change Plan form', 'wiloke'),
//					'desc_status'=>'info',
//					'name'    => 'wiloke_listgo[update_term]',
//					'id'      => '',
//					'post_type'=>'page',
//					'default' => ''
//				),
				array(
					'type'    => 'select_post',
					'heading' => esc_html__('Add Listing Page', 'wiloke'),
					'desc'    => esc_html__('This page tell Wiloke Submission where to add a listing on the front-end. To create an Add Listing Page, please click on Pages -> Add New -> Create a new page -> Assing that page to Add Listing Template', 'wiloke'),
					'desc_status'=>'info',
					'name'    => 'wiloke_listgo[addlisting]',
					'id'      => 'paypal_addlisting',
					'post_type'=>'page',
					'default' => ''
				),
				array(
					'type'    => 'select_post',
					'heading' => esc_html__('Checkout Page', 'wiloke'),
					'desc'    => esc_html__('To create an Checkout Page, please click on Pages -> Add New -> Create a new page -> Assing that page to Add Checkout Template', 'wiloke'),
					'name'    => 'wiloke_listgo[checkout]',
					'desc_status'=>'info',
					'id'      => 'paypal_checkoutpage',
					'post_type'=>'page',
					'default' => ''
				),
				array(
					'type'    => 'select_post',
					'heading' => esc_html__('My Account Page', 'wiloke'),
					'desc'    => esc_html__('To create an Checkout Page, please click on Pages -> Add New -> Create a new page -> Assing that page to User template', 'wiloke'),
					'name'    => 'wiloke_listgo[myaccount]',
					'desc_status'=>'info',
					'id'      => 'paypal_myaccount',
					'post_type'=>'page',
					'default' => ''
				),
				array(
					'type'    => 'select_post',
					'heading' => esc_html__('Thank you Page', 'wiloke'),
					'desc'    => esc_html__('Once your customer paid to you, the browser will redirect to this page.', 'wiloke'),
					'desc_status'=>'info',
					'name'    => 'wiloke_listgo[thankyou]',
					'id'      => 'paypal_thankyou',
					'post_type'=>'page',
					'default' => ''
				),
				array(
					'type'    => 'select_post',
					'heading' => esc_html__('Cancel Page', 'wiloke'),
					'desc'    => esc_html__('For example: When your customer click on Proceed to PayPal button but then he/she decided to cancel that session, then the browser will redirect to this page.', 'wiloke'),
					'desc_status'=>'info',
					'name'    => 'wiloke_listgo[cancel]',
					'id'      => 'paypal_cancel',
					'post_type'=>'page',
					'default' => ''
				),
				array(
					'text'    => esc_html__('Listings Expired Management', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Move listing to expired store after x days', 'wiloke'),
					'desc'    => esc_html__('When a listing is expired, It will be moved to expired store. It means this article will temporary removed from the front-end until the post author do a renew for it. Leave empty or 0 mean do it immediately.', 'wiloke'),
					'desc_status' => 'info',
					'name'    => 'wiloke_listgo[move_listing_to_expired_store_after]',
					'id'      => 'wiloke_listgo_move_listing_to_expired_store_after',
					'default' => 2
				),
				array(
					'text'    => esc_html__('Emails', 'wiloke'),
					'type'    => 'header',
					'class'   => 'dividing',
					'tag'     => 'h3'
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('"From" ', 'wiloke'),
					'name'    => 'wiloke_listgo[email_from]',
					'id'      => 'email_from',
					'placeholder'=>esc_html__('Leave empty to use the admin email', 'wiloke'),
					'default' => ''
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Logo (*)', 'wiloke'),
					'name'    => 'wiloke_listgo[email_logo_url]',
					'id'      => 'email_logo_url',
					'placeholder'=>'https://wiloke.com/images/logo.png',
					'desc'    => esc_html__('We recommend using an image of 224x90px', 'wiloke'),
					'desc_status'=>'info',
					'default' => ''
				),
				array(
					'type'    => 'textarea',
					'heading' => esc_html__('Signature', 'wiloke'),
					'name'    => 'wiloke_listgo[email_signature]',
					'id'      => 'email_signature',
					'placeholder'=>'Wiloke - Creative WordPress Theme',
					'default' => ''
				),
				array(
					'type'    => 'textarea',
					'heading' => esc_html__('Processing Payment', 'wiloke'),
					'name'    => 'wiloke_listgo[mail_processing_payment]',
					'id'      => 'mail_processing_payment',
					'default' => esc_html__('Congratulations! Your invoice has been received! [breakdown] Invoice Number: %invoice_number%. [breakdown]Payment Method: %payment_method%. [breakdown] Package Name: %package_title%.' , 'wiloke')
				),
				array(
					'type'    => 'textarea',
					'heading' => esc_html__('Completed Payment', 'wiloke'),
					'name'    => 'wiloke_listgo[mail_completed_payment]',
					'id'      => 'mail_completed_payment',
					'default' => esc_html__('Congratulations! Your payment has been successfully! [breakdown] Invoice Number: %invoice_number%. [breakdown] Payment Method: %payment_method%. [breakdown] Package Name: %package_title%.' , 'wiloke')
				),
				array(
					'type'    => 'textarea',
					'heading' => esc_html__('Failed Payment', 'wiloke'),
					'name'    => 'wiloke_listgo[mail_failed_payment]',
					'id'      => 'mail_failed_payment',
					'default' => esc_html__('Unfortunately, Your payment has been failed. [breakdown] Invoice Number: %invoice_number%. [breakdown] Payment Method: %payment_method%. [breakdown] Package Name: %package_title%. [breakdown] Invoice Date: %invoice_date%.' , 'wiloke')
				),
				array(
					'type'    => 'textarea',
					'heading' => esc_html__('Listing approved', 'wiloke'),
					'name'    => 'wiloke_listgo[mail_listing_approved]',
					'id'      => 'mail_listing_approved',
					'default' => esc_html__('Congratulations! Your submission - %post_title% - on %brand% has been approved. You can view your article here: %post_link%.[break_down] Thanks for your submission!' , 'wiloke')
				),
				array(
					'type'    => 'textarea',
					'heading' => esc_html__('Listing Expired', 'wiloke'),
					'name'    => 'wiloke_listgo[mail_listing_expired]',
					'id'      => 'mail_listing_expired',
					'default' => esc_html__('Dear %customer%! One of your listings with name %post_title% expired %expired%. But You can still renew now. If you wish to renew, simply click on the link below and follow the instructions. Renew now: %post_link%' , 'wiloke')
				),
				array(
					'type'    => 'textarea',
					'heading' => esc_html__('Notification for Out Balance account', 'wiloke'),
					'name'    => 'wiloke_listgo[mail_listing_outbalance]',
					'id'      => 'mail_listing_outbalance',
					'default' => esc_html__('Dear %customer%! Thank you for uploading with us! Unfortunately, we were not able to charge your PayPal account for your subscription as part of Subscription Pack %post_title% for the next billing, so to pay the balance please log into %homeurl% and make a payment through payment in the Dashboard\'s Billing section.' , 'wiloke')
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Log File Name', 'wiloke'),
					'name'    => 'wiloke_listgo[logfilename]',
					'id'      => 'paypal_logfilename',
					'default' => 'paypallog.txt'
				),
				array(
					'type'    => 'close_segment'
				),
				array(
					'type' => 'submit',
					'name' => esc_html__('Submit', 'wiloke')
				)
			)
		),
		'addneworder'=> array(
			'fields' => array(
				array(
					'type'    => 'select_user',
					'heading' => esc_html__('Grant Payment To', 'wiloke'),
					'desc' => esc_html__('Enter in username of the customer.', 'wiloke'),
					'desc_status' => 'info',
					'name'    => 'wiloke_listgo_order[user_ID]',
					'required'=> true,
					'id'      => 'add_new_order_user_ID',
					'default' => ''
				),
				array(
					'type'    => 'select',
					'heading' => esc_html__('Package Type', 'wiloke'),
					'desc'=> esc_html__('Buy Add Event package or Add Listing Package.', 'wiloke'),
					'desc_status' => 'info',
					'name'    => 'wiloke_listgo_order[package_type]',
					'required'=> true,
					'options' => array(
						'pricing'       => esc_html__('Add Listing Package', 'wiloke'),
						'event-pricing' => esc_html__('Add Event Package', 'wiloke')
					),
					'id'      => 'add_new_order_package_type',
					'default' => 'pricing'
				),
				array(
					'type'    => 'select_ui',
					'heading' => esc_html__('Select Add Listing Package', 'wiloke'),
					'desc'    => esc_html__('This setting is required by Add Listing Package', 'wiloke'),
					'desc_status' => 'info',
					'name'    => 'wiloke_listgo_order[package_ID]',
					'id'      => 'add_new_order_packageid',
					'post_type'=>'pricing',
					'default' => ''
				),
				array(
					'type'    => 'select_ui',
					'heading' => esc_html__('Select Add Event Package', 'wiloke'),
					'description' => esc_html__('This setting is required by Add Event Packae', 'wiloke'),
					'desc_status' => 'info',
					'name'    => 'wiloke_listgo_order[event_plan_ID]',
					'id'      => 'add_new_order_add_event_planid',
					'post_type'=>'event-pricing',
					'default' => ''
				),
				array(
					'type'    => 'select',
					'heading' => esc_html__('Order Status', 'wiloke'),
					'name'    => 'wiloke_listgo_order[status]',
					'required'=>true,
					'id'      => 'add_new_order_status',
					'options' => array(
						'completed'     => esc_html__('Completed', 'wiloke'),
						'pending'       => esc_html__('Pending', 'wiloke'),
						'processing'    => esc_html__('Processing', 'wiloke'),
						'canceled'      => esc_html__('Canceled', 'wiloke'),
						'failed'        => esc_html__('Failed', 'wiloke')
					),
					'default' => 'completed'
				),
				array(
					'type' => 'submit',
					'name' => esc_html__('Submit', 'wiloke')
				)
			)
		),
		'claim' => array(
			'fields' => array(
				array(
					'type'    => 'select_ui',
					'heading' => esc_html__('Listings For Claim', 'wiloke'),
					'name'    => 'wiloke_listgo_claim[listing]',
					'required'=> true,
					'post_type'=>'listing',
					'id'      => 'listing_for_claim',
					'default' => ''
				),
				array(
					'type'    => 'select_user',
					'heading' => esc_html__('Listing Author', 'wiloke'),
					'name'    => 'wiloke_listgo_claim[listing_author]',
					'id'      => 'listing_author',
					'default' => ''
				),
				array(
					'type'    => 'select_user',
					'heading' => esc_html__('Claimed By', 'wiloke'),
					'name'    => 'wiloke_listgo_claim[claimed_by]',
					'required'=> true,
					'id'      => 'claimed_by',
					'default' => ''
				),
				array(
					'type'    => 'select',
					'heading' => esc_html__('Status', 'wiloke'),
					'name'    => 'wiloke_listgo_claim[status]',
					'required'=>true,
					'id'      => 'claim_status',
					'options' => array(
						'approved'  => esc_html__('Approved', 'wiloke'),
						'pending'   => esc_html__('Pending', 'wiloke'),
						'decline'   => esc_html__('Decline', 'wiloke')
					),
					'default' => 'pending'
				),
				array(
					'type'    => 'text',
					'heading' => esc_html__('Claimer Phone', 'wiloke'),
					'name'    => 'wiloke_listgo_claim[phone]',
					'required'=>true,
					'id'      => 'claim_phone',
					'default' => ''
				)
			),
			'delete_others' => array(
				array(
					'type'           => 'text',
					'heading'        => esc_html__('Enter "delete" text in this field to confirm your action', 'wiloke'),
					'desc'           => esc_html__('Delete the rest claims of people who also claimed this listing.', 'wiloke'),
					'desc_status'    => 'info',
					'name'           => 'wiloke_listgo_delete_rest_claims',
					'id'             => 'confirm_claim',
					'default'        => ''
				),
				array(
					'type' => 'submit',
					'name' => esc_html__('Submit', 'wiloke')
				)
			)
		),
		'show_events_on_carousel_shortcode' => array(
			'type'    => 'select',
			'heading' => esc_html__('Toggle Show Event On Event Carousel Shortcode', 'wiloke'),
			'desc'    => esc_html__('All events that belong to this plan will be shown/hidden on the event carousel shortcode. Events Carousel shortcode is a extended Visual Composer shortcode.', 'wiloke'),
			'desc_status' => 'info',
			'name'    => 'toggle_show_events_on_event_carousel',
			'required'=>true,
			'id'      => 'toggle_show_events_on_event_carousel',
			'options' => array(
				'disable'  => esc_html__('Disable', 'wiloke'),
				'enable'   => esc_html__('Enable', 'wiloke')
			),
			'default' => 'disable'
		),
		'show_events_on_list_shortcode' => array(
			'type'    => 'select',
			'heading' => esc_html__('Toggle Show Event On Event Listing Shortcode', 'wiloke'),
			'desc'    => esc_html__('All events that belong to this plan will be shown/hidden on the event listing shortcode. Events List shortcode is a extended Visual Composer shortcode.', 'wiloke'),
			'desc_status' => 'info',
			'name'    => 'toggle_show_events_on_event_listing',
			'required'=>true,
			'id'      => 'toggle_show_events_on_event_listing',
			'options' => array(
				'disable'  => esc_html__('Disable', 'wiloke'),
				'enable'   => esc_html__('Enable', 'wiloke')
			),
			'default' => 'disable'
		),
		'show_events_on_sidebar' => array(
			'type'    => 'select',
			'heading' => esc_html__('Toggle Show Event On Sidebar', 'wiloke'),
			'desc'    => esc_html__('All events that belong to this plan will be shown/hidden on the sidebar (Appearance -> Widgets -> Wiloke Events widget)', 'wiloke'),
			'desc_status' => 'info',
			'name'    => 'toggle_show_events_on_sidebar',
			'required'=>true,
			'id'      => 'toggle_show_events_on_sidebar',
			'options' => array(
				'disable'  => esc_html__('Disable', 'wiloke'),
				'enable'   => esc_html__('Enable', 'wiloke')
			),
			'default' => 'disable'
		),
	),
	'countryCode' => array(
		'AF' => esc_html__( 'Afghanistan', 'wiloke' ),
		'AX' => esc_html__( '&#197;land Islands', 'wiloke' ),
		'AL' => esc_html__( 'Albania', 'wiloke' ),
		'DZ' => esc_html__( 'Algeria', 'wiloke' ),
		'AS' => esc_html__( 'American Samoa', 'wiloke' ),
		'AD' => esc_html__( 'Andorra', 'wiloke' ),
		'AO' => esc_html__( 'Angola', 'wiloke' ),
		'AI' => esc_html__( 'Anguilla', 'wiloke' ),
		'AQ' => esc_html__( 'Antarctica', 'wiloke' ),
		'AG' => esc_html__( 'Antigua and Barbuda', 'wiloke' ),
		'AR' => esc_html__( 'Argentina', 'wiloke' ),
		'AM' => esc_html__( 'Armenia', 'wiloke' ),
		'AW' => esc_html__( 'Aruba', 'wiloke' ),
		'AU' => esc_html__( 'Australia', 'wiloke' ),
		'AT' => esc_html__( 'Austria', 'wiloke' ),
		'AZ' => esc_html__( 'Azerbaijan', 'wiloke' ),
		'BS' => esc_html__( 'Bahamas', 'wiloke' ),
		'BH' => esc_html__( 'Bahrain', 'wiloke' ),
		'BD' => esc_html__( 'Bangladesh', 'wiloke' ),
		'BB' => esc_html__( 'Barbados', 'wiloke' ),
		'BY' => esc_html__( 'Belarus', 'wiloke' ),
		'BE' => esc_html__( 'Belgium', 'wiloke' ),
		'PW' => esc_html__( 'Belau', 'wiloke' ),
		'BZ' => esc_html__( 'Belize', 'wiloke' ),
		'BJ' => esc_html__( 'Benin', 'wiloke' ),
		'BM' => esc_html__( 'Bermuda', 'wiloke' ),
		'BT' => esc_html__( 'Bhutan', 'wiloke' ),
		'BO' => esc_html__( 'Bolivia', 'wiloke' ),
		'BQ' => esc_html__( 'Bonaire, Saint Eustatius and Saba', 'wiloke' ),
		'BA' => esc_html__( 'Bosnia and Herzegovina', 'wiloke' ),
		'BW' => esc_html__( 'Botswana', 'wiloke' ),
		'BV' => esc_html__( 'Bouvet Island', 'wiloke' ),
		'BR' => esc_html__( 'Brazil', 'wiloke' ),
		'IO' => esc_html__( 'British Indian Ocean Territory', 'wiloke' ),
		'VG' => esc_html__( 'British Virgin Islands', 'wiloke' ),
		'BN' => esc_html__( 'Brunei', 'wiloke' ),
		'BG' => esc_html__( 'Bulgaria', 'wiloke' ),
		'BF' => esc_html__( 'Burkina Faso', 'wiloke' ),
		'BI' => esc_html__( 'Burundi', 'wiloke' ),
		'KH' => esc_html__( 'Cambodia', 'wiloke' ),
		'CM' => esc_html__( 'Cameroon', 'wiloke' ),
		'CA' => esc_html__( 'Canada', 'wiloke' ),
		'CV' => esc_html__( 'Cape Verde', 'wiloke' ),
		'KY' => esc_html__( 'Cayman Islands', 'wiloke' ),
		'CF' => esc_html__( 'Central African Republic', 'wiloke' ),
		'TD' => esc_html__( 'Chad', 'wiloke' ),
		'CL' => esc_html__( 'Chile', 'wiloke' ),
		'CN' => esc_html__( 'China', 'wiloke' ),
		'CX' => esc_html__( 'Christmas Island', 'wiloke' ),
		'CC' => esc_html__( 'Cocos (Keeling) Islands', 'wiloke' ),
		'CO' => esc_html__( 'Colombia', 'wiloke' ),
		'KM' => esc_html__( 'Comoros', 'wiloke' ),
		'CG' => esc_html__( 'Congo (Brazzaville)', 'wiloke' ),
		'CD' => esc_html__( 'Congo (Kinshasa)', 'wiloke' ),
		'CK' => esc_html__( 'Cook Islands', 'wiloke' ),
		'CR' => esc_html__( 'Costa Rica', 'wiloke' ),
		'HR' => esc_html__( 'Croatia', 'wiloke' ),
		'CU' => esc_html__( 'Cuba', 'wiloke' ),
		'CW' => esc_html__( 'Cura&ccedil;ao', 'wiloke' ),
		'CY' => esc_html__( 'Cyprus', 'wiloke' ),
		'CZ' => esc_html__( 'Czech Republic', 'wiloke' ),
		'DK' => esc_html__( 'Denmark', 'wiloke' ),
		'DJ' => esc_html__( 'Djibouti', 'wiloke' ),
		'DM' => esc_html__( 'Dominica', 'wiloke' ),
		'DO' => esc_html__( 'Dominican Republic', 'wiloke' ),
		'EC' => esc_html__( 'Ecuador', 'wiloke' ),
		'EG' => esc_html__( 'Egypt', 'wiloke' ),
		'SV' => esc_html__( 'El Salvador', 'wiloke' ),
		'GQ' => esc_html__( 'Equatorial Guinea', 'wiloke' ),
		'ER' => esc_html__( 'Eritrea', 'wiloke' ),
		'EE' => esc_html__( 'Estonia', 'wiloke' ),
		'ET' => esc_html__( 'Ethiopia', 'wiloke' ),
		'FK' => esc_html__( 'Falkland Islands', 'wiloke' ),
		'FO' => esc_html__( 'Faroe Islands', 'wiloke' ),
		'FJ' => esc_html__( 'Fiji', 'wiloke' ),
		'FI' => esc_html__( 'Finland', 'wiloke' ),
		'FR' => esc_html__( 'France', 'wiloke' ),
		'GF' => esc_html__( 'French Guiana', 'wiloke' ),
		'PF' => esc_html__( 'French Polynesia', 'wiloke' ),
		'TF' => esc_html__( 'French Southern Territories', 'wiloke' ),
		'GA' => esc_html__( 'Gabon', 'wiloke' ),
		'GM' => esc_html__( 'Gambia', 'wiloke' ),
		'GE' => esc_html__( 'Georgia', 'wiloke' ),
		'DE' => esc_html__( 'Germany', 'wiloke' ),
		'GH' => esc_html__( 'Ghana', 'wiloke' ),
		'GI' => esc_html__( 'Gibraltar', 'wiloke' ),
		'GR' => esc_html__( 'Greece', 'wiloke' ),
		'GL' => esc_html__( 'Greenland', 'wiloke' ),
		'GD' => esc_html__( 'Grenada', 'wiloke' ),
		'GP' => esc_html__( 'Guadeloupe', 'wiloke' ),
		'GU' => esc_html__( 'Guam', 'wiloke' ),
		'GT' => esc_html__( 'Guatemala', 'wiloke' ),
		'GG' => esc_html__( 'Guernsey', 'wiloke' ),
		'GN' => esc_html__( 'Guinea', 'wiloke' ),
		'GW' => esc_html__( 'Guinea-Bissau', 'wiloke' ),
		'GY' => esc_html__( 'Guyana', 'wiloke' ),
		'HT' => esc_html__( 'Haiti', 'wiloke' ),
		'HM' => esc_html__( 'Heard Island and McDonald Islands', 'wiloke' ),
		'HN' => esc_html__( 'Honduras', 'wiloke' ),
		'HK' => esc_html__( 'Hong Kong', 'wiloke' ),
		'HU' => esc_html__( 'Hungary', 'wiloke' ),
		'IS' => esc_html__( 'Iceland', 'wiloke' ),
		'IN' => esc_html__( 'India', 'wiloke' ),
		'ID' => esc_html__( 'Indonesia', 'wiloke' ),
		'IR' => esc_html__( 'Iran', 'wiloke' ),
		'IQ' => esc_html__( 'Iraq', 'wiloke' ),
		'IE' => esc_html__( 'Ireland', 'wiloke' ),
		'IM' => esc_html__( 'Isle of Man', 'wiloke' ),
		'IL' => esc_html__( 'Israel', 'wiloke' ),
		'IT' => esc_html__( 'Italy', 'wiloke' ),
		'CI' => esc_html__( 'Ivory Coast', 'wiloke' ),
		'JM' => esc_html__( 'Jamaica', 'wiloke' ),
		'JP' => esc_html__( 'Japan', 'wiloke' ),
		'JE' => esc_html__( 'Jersey', 'wiloke' ),
		'JO' => esc_html__( 'Jordan', 'wiloke' ),
		'KZ' => esc_html__( 'Kazakhstan', 'wiloke' ),
		'KE' => esc_html__( 'Kenya', 'wiloke' ),
		'KI' => esc_html__( 'Kiribati', 'wiloke' ),
		'KW' => esc_html__( 'Kuwait', 'wiloke' ),
		'KG' => esc_html__( 'Kyrgyzstan', 'wiloke' ),
		'LA' => esc_html__( 'Laos', 'wiloke' ),
		'LV' => esc_html__( 'Latvia', 'wiloke' ),
		'LB' => esc_html__( 'Lebanon', 'wiloke' ),
		'LS' => esc_html__( 'Lesotho', 'wiloke' ),
		'LR' => esc_html__( 'Liberia', 'wiloke' ),
		'LY' => esc_html__( 'Libya', 'wiloke' ),
		'LI' => esc_html__( 'Liechtenstein', 'wiloke' ),
		'LT' => esc_html__( 'Lithuania', 'wiloke' ),
		'LU' => esc_html__( 'Luxembourg', 'wiloke' ),
		'MO' => esc_html__( 'Macao S.A.R., China', 'wiloke' ),
		'MK' => esc_html__( 'Macedonia', 'wiloke' ),
		'MG' => esc_html__( 'Madagascar', 'wiloke' ),
		'MW' => esc_html__( 'Malawi', 'wiloke' ),
		'MY' => esc_html__( 'Malaysia', 'wiloke' ),
		'MV' => esc_html__( 'Maldives', 'wiloke' ),
		'ML' => esc_html__( 'Mali', 'wiloke' ),
		'MT' => esc_html__( 'Malta', 'wiloke' ),
		'MH' => esc_html__( 'Marshall Islands', 'wiloke' ),
		'MQ' => esc_html__( 'Martinique', 'wiloke' ),
		'MR' => esc_html__( 'Mauritania', 'wiloke' ),
		'MU' => esc_html__( 'Mauritius', 'wiloke' ),
		'YT' => esc_html__( 'Mayotte', 'wiloke' ),
		'MX' => esc_html__( 'Mexico', 'wiloke' ),
		'FM' => esc_html__( 'Micronesia', 'wiloke' ),
		'MD' => esc_html__( 'Moldova', 'wiloke' ),
		'MC' => esc_html__( 'Monaco', 'wiloke' ),
		'MN' => esc_html__( 'Mongolia', 'wiloke' ),
		'ME' => esc_html__( 'Montenegro', 'wiloke' ),
		'MS' => esc_html__( 'Montserrat', 'wiloke' ),
		'MA' => esc_html__( 'Morocco', 'wiloke' ),
		'MZ' => esc_html__( 'Mozambique', 'wiloke' ),
		'MM' => esc_html__( 'Myanmar', 'wiloke' ),
		'NA' => esc_html__( 'Namibia', 'wiloke' ),
		'NR' => esc_html__( 'Nauru', 'wiloke' ),
		'NP' => esc_html__( 'Nepal', 'wiloke' ),
		'NL' => esc_html__( 'Netherlands', 'wiloke' ),
		'NC' => esc_html__( 'New Caledonia', 'wiloke' ),
		'NZ' => esc_html__( 'New Zealand', 'wiloke' ),
		'NI' => esc_html__( 'Nicaragua', 'wiloke' ),
		'NE' => esc_html__( 'Niger', 'wiloke' ),
		'NG' => esc_html__( 'Nigeria', 'wiloke' ),
		'NU' => esc_html__( 'Niue', 'wiloke' ),
		'NF' => esc_html__( 'Norfolk Island', 'wiloke' ),
		'MP' => esc_html__( 'Northern Mariana Islands', 'wiloke' ),
		'KP' => esc_html__( 'North Korea', 'wiloke' ),
		'NO' => esc_html__( 'Norway', 'wiloke' ),
		'OM' => esc_html__( 'Oman', 'wiloke' ),
		'PK' => esc_html__( 'Pakistan', 'wiloke' ),
		'PS' => esc_html__( 'Palestinian Territory', 'wiloke' ),
		'PA' => esc_html__( 'Panama', 'wiloke' ),
		'PG' => esc_html__( 'Papua New Guinea', 'wiloke' ),
		'PY' => esc_html__( 'Paraguay', 'wiloke' ),
		'PE' => esc_html__( 'Peru', 'wiloke' ),
		'PH' => esc_html__( 'Philippines', 'wiloke' ),
		'PN' => esc_html__( 'Pitcairn', 'wiloke' ),
		'PL' => esc_html__( 'Poland', 'wiloke' ),
		'PT' => esc_html__( 'Portugal', 'wiloke' ),
		'PR' => esc_html__( 'Puerto Rico', 'wiloke' ),
		'QA' => esc_html__( 'Qatar', 'wiloke' ),
		'RE' => esc_html__( 'Reunion', 'wiloke' ),
		'RO' => esc_html__( 'Romania', 'wiloke' ),
		'RU' => esc_html__( 'Russia', 'wiloke' ),
		'RW' => esc_html__( 'Rwanda', 'wiloke' ),
		'BL' => esc_html__( 'Saint Barth&eacute;lemy', 'wiloke' ),
		'SH' => esc_html__( 'Saint Helena', 'wiloke' ),
		'KN' => esc_html__( 'Saint Kitts and Nevis', 'wiloke' ),
		'LC' => esc_html__( 'Saint Lucia', 'wiloke' ),
		'MF' => esc_html__( 'Saint Martin (French part)', 'wiloke' ),
		'SX' => esc_html__( 'Saint Martin (Dutch part)', 'wiloke' ),
		'PM' => esc_html__( 'Saint Pierre and Miquelon', 'wiloke' ),
		'VC' => esc_html__( 'Saint Vincent and the Grenadines', 'wiloke' ),
		'SM' => esc_html__( 'San Marino', 'wiloke' ),
		'ST' => esc_html__( 'S&atilde;o Tom&eacute; and Pr&iacute;ncipe', 'wiloke' ),
		'SA' => esc_html__( 'Saudi Arabia', 'wiloke' ),
		'SN' => esc_html__( 'Senegal', 'wiloke' ),
		'RS' => esc_html__( 'Serbia', 'wiloke' ),
		'SC' => esc_html__( 'Seychelles', 'wiloke' ),
		'SL' => esc_html__( 'Sierra Leone', 'wiloke' ),
		'SG' => esc_html__( 'Singapore', 'wiloke' ),
		'SK' => esc_html__( 'Slovakia', 'wiloke' ),
		'SI' => esc_html__( 'Slovenia', 'wiloke' ),
		'SB' => esc_html__( 'Solomon Islands', 'wiloke' ),
		'SO' => esc_html__( 'Somalia', 'wiloke' ),
		'ZA' => esc_html__( 'South Africa', 'wiloke' ),
		'GS' => esc_html__( 'South Georgia/Sandwich Islands', 'wiloke' ),
		'KR' => esc_html__( 'South Korea', 'wiloke' ),
		'SS' => esc_html__( 'South Sudan', 'wiloke' ),
		'ES' => esc_html__( 'Spain', 'wiloke' ),
		'LK' => esc_html__( 'Sri Lanka', 'wiloke' ),
		'SD' => esc_html__( 'Sudan', 'wiloke' ),
		'SR' => esc_html__( 'Suriname', 'wiloke' ),
		'SJ' => esc_html__( 'Svalbard and Jan Mayen', 'wiloke' ),
		'SZ' => esc_html__( 'Swaziland', 'wiloke' ),
		'SE' => esc_html__( 'Sweden', 'wiloke' ),
		'CH' => esc_html__( 'Switzerland', 'wiloke' ),
		'SY' => esc_html__( 'Syria', 'wiloke' ),
		'TW' => esc_html__( 'Taiwan', 'wiloke' ),
		'TJ' => esc_html__( 'Tajikistan', 'wiloke' ),
		'TZ' => esc_html__( 'Tanzania', 'wiloke' ),
		'TH' => esc_html__( 'Thailand', 'wiloke' ),
		'TL' => esc_html__( 'Timor-Leste', 'wiloke' ),
		'TG' => esc_html__( 'Togo', 'wiloke' ),
		'TK' => esc_html__( 'Tokelau', 'wiloke' ),
		'TO' => esc_html__( 'Tonga', 'wiloke' ),
		'TT' => esc_html__( 'Trinidad and Tobago', 'wiloke' ),
		'TN' => esc_html__( 'Tunisia', 'wiloke' ),
		'TR' => esc_html__( 'Turkey', 'wiloke' ),
		'TM' => esc_html__( 'Turkmenistan', 'wiloke' ),
		'TC' => esc_html__( 'Turks and Caicos Islands', 'wiloke' ),
		'TV' => esc_html__( 'Tuvalu', 'wiloke' ),
		'UG' => esc_html__( 'Uganda', 'wiloke' ),
		'UA' => esc_html__( 'Ukraine', 'wiloke' ),
		'AE' => esc_html__( 'United Arab Emirates', 'wiloke' ),
		'GB' => esc_html__( 'United Kingdom (UK)', 'wiloke' ),
		'US' => esc_html__( 'United States (US)', 'wiloke' ),
		'UM' => esc_html__( 'United States (US) Minor Outlying Islands', 'wiloke' ),
		'VI' => esc_html__( 'United States (US) Virgin Islands', 'wiloke' ),
		'UY' => esc_html__( 'Uruguay', 'wiloke' ),
		'UZ' => esc_html__( 'Uzbekistan', 'wiloke' ),
		'VU' => esc_html__( 'Vanuatu', 'wiloke' ),
		'VA' => esc_html__( 'Vatican', 'wiloke' ),
		'VE' => esc_html__( 'Venezuela', 'wiloke' ),
		'VN' => esc_html__( 'Vietnam', 'wiloke' ),
		'WF' => esc_html__( 'Wallis and Futuna', 'wiloke' ),
		'EH' => esc_html__( 'Western Sahara', 'wiloke' ),
		'WS' => esc_html__( 'Samoa', 'wiloke' ),
		'YE' => esc_html__( 'Yemen', 'wiloke' ),
		'ZM' => esc_html__( 'Zambia', 'wiloke' ),
		'ZW' => esc_html__( 'Zimbabwe', 'wiloke' ),
		'IND' => esc_html__( 'India', 'wiloke' ),
	),
	'currencySymbol' => array(
		'AED' => '&#x62f;.&#x625;',
		'AFN' => '&#x60b;',
		'ALL' => 'L',
		'AMD' => 'AMD',
		'ANG' => '&fnof;',
		'AOA' => 'Kz',
		'ARS' => '&#36;',
		'AUD' => '&#36;',
		'AWG' => '&fnof;',
		'AZN' => 'AZN',
		'BAM' => 'KM',
		'BBD' => '&#36;',
		'BDT' => '&#2547;&nbsp;',
		'BGN' => '&#1083;&#1074;.',
		'BHD' => '.&#x62f;.&#x628;',
		'BIF' => 'Fr',
		'BMD' => '&#36;',
		'BND' => '&#36;',
		'BOB' => 'Bs.',
		'BRL' => '&#82;&#36;',
		'BSD' => '&#36;',
		'BTC' => '&#3647;',
		'BTN' => 'Nu.',
		'BWP' => 'P',
		'BYR' => 'Br',
		'BZD' => '&#36;',
		'CAD' => '&#36;',
		'CDF' => 'Fr',
		'CHF' => '&#67;&#72;&#70;',
		'CLP' => '&#36;',
		'CNY' => '&yen;',
		'COP' => '&#36;',
		'CRC' => '&#x20a1;',
		'CUC' => '&#36;',
		'CUP' => '&#36;',
		'CVE' => '&#36;',
		'CZK' => '&#75;&#269;',
		'DJF' => 'Fr',
		'DKK' => 'DKK',
		'DOP' => 'RD&#36;',
		'DZD' => '&#x62f;.&#x62c;',
		'EGP' => 'EGP',
		'ERN' => 'Nfk',
		'ETB' => 'Br',
		'EUR' => '&euro;',
		'FJD' => '&#36;',
		'FKP' => '&pound;',
		'GBP' => '&pound;',
		'GEL' => '&#x10da;',
		'GGP' => '&pound;',
		'GHS' => '&#x20b5;',
		'GIP' => '&pound;',
		'GMD' => 'D',
		'GNF' => 'Fr',
		'GTQ' => 'Q',
		'GYD' => '&#36;',
		'HKD' => '&#36;',
		'HNL' => 'L',
		'HRK' => 'Kn',
		'HTG' => 'G',
		'HUF' => '&#70;&#116;',
		'IDR' => 'Rp',
		'ILS' => '&#8362;',
		'IMP' => '&pound;',
		'INR' => '&#8377;',
		'IQD' => '&#x639;.&#x62f;',
		'IRR' => '&#xfdfc;',
		'IRT' => '&#x062A;&#x0648;&#x0645;&#x0627;&#x0646;',
		'ISK' => 'kr.',
		'JEP' => '&pound;',
		'JMD' => '&#36;',
		'JOD' => '&#x62f;.&#x627;',
		'JPY' => '&yen;',
		'KES' => 'KSh',
		'KGS' => '&#x441;&#x43e;&#x43c;',
		'KHR' => '&#x17db;',
		'KMF' => 'Fr',
		'KPW' => '&#x20a9;',
		'KRW' => '&#8361;',
		'KWD' => '&#x62f;.&#x643;',
		'KYD' => '&#36;',
		'KZT' => 'KZT',
		'LAK' => '&#8365;',
		'LBP' => '&#x644;.&#x644;',
		'LKR' => '&#xdbb;&#xdd4;',
		'LRD' => '&#36;',
		'LSL' => 'L',
		'LYD' => '&#x644;.&#x62f;',
		'MAD' => '&#x62f;.&#x645;.',
		'MDL' => 'MDL',
		'MGA' => 'Ar',
		'MKD' => '&#x434;&#x435;&#x43d;',
		'MMK' => 'Ks',
		'MNT' => '&#x20ae;',
		'MOP' => 'P',
		'MRO' => 'UM',
		'MUR' => '&#x20a8;',
		'MVR' => '.&#x783;',
		'MWK' => 'MK',
		'MXN' => '&#36;',
		'MYR' => '&#82;&#77;',
		'MZN' => 'MT',
		'NAD' => '&#36;',
		'NGN' => '&#8358;',
		'NIO' => 'C&#36;',
		'NOK' => '&#107;&#114;',
		'NPR' => '&#8360;',
		'NZD' => '&#36;',
		'OMR' => '&#x631;.&#x639;.',
		'PAB' => 'B/.',
		'PEN' => 'S/.',
		'PGK' => 'K',
		'PHP' => '&#8369;',
		'PKR' => '&#8360;',
		'PLN' => '&#122;&#322;',
		'PRB' => '&#x440;.',
		'PYG' => '&#8370;',
		'QAR' => '&#x631;.&#x642;',
		'RMB' => '&yen;',
		'RON' => 'lei',
		'RSD' => '&#x434;&#x438;&#x43d;.',
		'RUB' => '&#8381;',
		'RWF' => 'Fr',
		'SAR' => '&#x631;.&#x633;',
		'SBD' => '&#36;',
		'SCR' => '&#x20a8;',
		'SDG' => '&#x62c;.&#x633;.',
		'SEK' => '&#107;&#114;',
		'SGD' => '&#36;',
		'SHP' => '&pound;',
		'SLL' => 'Le',
		'SOS' => 'Sh',
		'SRD' => '&#36;',
		'SSP' => '&pound;',
		'STD' => 'Db',
		'SYP' => '&#x644;.&#x633;',
		'SZL' => 'L',
		'THB' => '&#3647;',
		'TJS' => '&#x405;&#x41c;',
		'TMT' => 'm',
		'TND' => '&#x62f;.&#x62a;',
		'TOP' => 'T&#36;',
		'TRY' => '&#8378;',
		'TTD' => '&#36;',
		'TWD' => '&#78;&#84;&#36;',
		'TZS' => 'Sh',
		'UAH' => '&#8372;',
		'UGX' => 'UGX',
		'USD' => '&#36;',
		'UYU' => '&#36;',
		'UZS' => 'UZS',
		'VEF' => 'Bs F',
		'VND' => '&#8363;',
		'VUV' => 'Vt',
		'WST' => 'T',
		'XAF' => 'Fr',
		'XCD' => '&#36;',
		'XOF' => 'Fr',
		'XPF' => 'Fr',
		'YER' => '&#xfdfc;',
		'ZAR' => '&#82;',
		'ZMW' => 'ZK'
	)
];