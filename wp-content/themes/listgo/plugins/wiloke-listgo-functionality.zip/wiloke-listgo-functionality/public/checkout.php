<?php
/*
 |--------------------------------------------------------------------------
 | Check Out Page
 |--------------------------------------------------------------------------
 |
 | @since 1.0
 | This page is the last place to fill in your information before redirecting to external Payment page
 */