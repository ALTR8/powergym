<?php
/*
 * Payment Interface
 * @since 1.0
 */
namespace WilokeListGoFunctionality\Payment;

interface PaymentMethodInterface{
	public function acceptPayment($receipt);
}