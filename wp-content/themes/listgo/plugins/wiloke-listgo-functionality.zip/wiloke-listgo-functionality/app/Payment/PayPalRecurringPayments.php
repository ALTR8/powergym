<?php
namespace WilokeListGoFunctionality\Payment;


class PayPalRecurringPayments{
//	protected function
}