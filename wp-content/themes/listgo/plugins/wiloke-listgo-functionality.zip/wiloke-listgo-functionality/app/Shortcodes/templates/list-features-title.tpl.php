<script id="list-features-title-tpl" type="text/html">
    <div class="addlisting-popup__field">
        <input placeholder="<?php esc_html_e('Title', 'wiloke'); ?>" id="list-features-title" type="text" name="title" value="<%= title %>">
    </div>
</script>