<?php
/**
 * Design Register Way
 * @since 1.0
 */
namespace WilokeListGoFunctionality\Register;

interface RegisterInterface{
    public function __construct();
    public function register();
}