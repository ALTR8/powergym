<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>{{wiloke_title}}</title>
</head>

<body>
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f5f4f1 url()">
	<tbody>
	<tr>
		<td valign="top" width="100%" align="center">
			<table width="700" cellpadding="0" cellspacing="0" border="0" style="margin:0 10px">
				<tbody>
				<tr>
					<td width="20" style="margin:0;padding:0;font-size:0;line-height:0">&nbsp;</td>
					<td align="left">
						<table width="660" cellpadding="0" cellspacing="0" border="0">
							<tbody>
							<tr>
								<td height="40" style="margin:0;padding:0;font-size:0;line-height:0"></td>
							</tr>
							<tr>
								<td align="center">
									<a href="#" target="_blank"><img src="{{wiloke_logo}}" width="224" height="87" alt="{{wiloke_brandname}}" border="0" class="CToWUd"></a>
								</td>
							</tr>
							<tr>
								<td height="40" style="margin:0;padding:0;font-size:0;line-height:0;border-bottom:1px solid #e4e2dc"></td>
							</tr>
							<tr>
								<td height="28" style="margin:0;padding:0;font-size:0;line-height:0"></td>
							</tr>
							<tr>
								<td height="57" valign="top" style="color:#7b7771;font:18px/23px 'helvetica neue',helvetica,arial,sans-serif;padding:0;margin:0;text-align:left" align="center">
									{{wiloke_say_hello}}
								</td>
							</tr>
							<tr>
								<td style="color:#7b7771;font:16px/24px 'helvetica neue',helvetica,arial,sans-serif;padding:0;margin:0" valign="top">
									<table width="700" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>