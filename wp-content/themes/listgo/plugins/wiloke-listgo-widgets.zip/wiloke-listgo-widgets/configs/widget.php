<?php
/**
 * Created by PhpStorm.
 * User: pirates
 * Date: 5/17/17
 * Time: 11:12 PM
 */

return array(
	'WilokeListingInformation',
	'WilokeOpeningHours',
	'WilokeListingPrice',
	'WilokeContactFormSeven',
	'WilokeMap',
	'WilokeGallery',
	'WilokeListingPosts',
	'WilokeListOfTerms',
	'WilokeFlickr',
	'WilokeInstagram',
	'WilokeTwitterFeeds',
	'WilokeSimplePostsSlider',
	'WilokeMailChimp',
	'WilokeContentBox',
	'WilokeAuthorInformation',
	'WilokeRegistrationForm',
	'WilokeOpenTable',
	'WilokeMyApps',
	'WilokeEvents'
);