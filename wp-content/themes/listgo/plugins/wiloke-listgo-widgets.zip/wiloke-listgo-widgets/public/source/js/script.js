;(function ($) {
	'use strict';
	let isFetchedEvent = false;

	function subscribe() {
		let $wilokeSubscribe = $('.wiloke-submit-subscribe');

		$wilokeSubscribe.on('click', (event=>{
			event.preventDefault();

			let xhr         = null,
				$self       = $(event.currentTarget),
				currentBtnName = $self.html(),
				$form       = $self.closest('form'),
				$message    = $form.find('.message'),
				email       = $form.find('.wiloke-subscribe-email').val();

			if ( xhr !== null && xhr.status !==  200 ){
				xhr.abort();
			}

			if ( email !== '' )
			{
				$self.val( $self.attr('data-handle') );
				$self.html($self.data('sendingtext') + ' <i class="icon_mail_alt"></i>');
				$.ajax({
					type: 'POST',
					url: WILOKE_GLOBAL.ajaxurl,
					data: { action: 'wiloke_mailchimp_subscribe', security: WILOKE_GLOBAL.wiloke_nonce, email: email },
					success: (response=>{
						if ( response.success ){
							$message.html(response.data).addClass('alert-done').removeClass('alert-error').fadeIn();
							$form.find('.form-remove').remove();
						}else{
							$message.html(response.data).addClass('alert-error').removeClass('alert-done').fadeIn();
						}
						$self.html(currentBtnName);
					})
				});
			}else{
				$message.html('Please enter your e-mail').addClass('alert-error').removeClass('alert-done').fadeIn();
			}
			return false;
		}));
	}
	
	function openTable() {
		let now = (Date.now() - 86400000); //allow today to be selected
		$( "#listgo-open-table-startdate" ).datepicker({
			autopick : true,
			altField: '#listgo-open-table-startdate-input',
			altFormat: "mm/dd/yy",
			inline: true,
			weekStart: 0,
			filter: function ( date ) {
				return date.valueOf() >= now;
			}
		}).trigger('change');
	}

	function showEventNearByCustomer(){
		if ( !$('.widget.show_event_near_by_customer').length ){
			return false;
		}

		let oCustomerGeocode = localStorage.getItem('listgo_mylocation'),
			createdAt = localStorage.getItem('listgo_mylocation_created_at');

		if ( oCustomerGeocode ){
			let instDate = new Date();
			if ( (instDate.getMinutes() - parseInt(createdAt, 10)) <= 5 ){
				oCustomerGeocode = $.parseJSON(oCustomerGeocode);

				if ( !_.isEmpty(oCustomerGeocode) ){
					fetchEvent(oCustomerGeocode);
				}
			}
		}

		$('body').on('wiloke_listgo_got_geocode', ((event, position)=>{
			if ( position !== false ){
				let oLatLng = {
					lat: position.coords.latitude,
					lng: position.coords.longitude
				};
				fetchEvent(oLatLng);
			}
		}));
	}
	
	function fetchEvent(oLatLng) {
		let $widget = $('.widget.show_event_near_by_customer');
		$.ajax({
			type: 'GET',
			url: WILOKE_GLOBAL.ajaxurl,
			data: {
				action: 'fetch_event_show_on_sidebar',
				latLng: oLatLng,
				numberOfEvents: $widget.data('numberofevents'),
				orderBy: $widget.data('orderby')
			},
			success: (response=>{
				if ( response.success ){
					$widget.removeClass('block-loading');
					$widget.find('.widget-events__body').html(response.data.msg);
				}else{
					$widget.closest('.widget_events').remove();
				}

			})
		})
	}

	$(document).ready(function () {
		subscribe();
		openTable();
		showEventNearByCustomer();

		setTimeout(function () {
			if ( !isFetchedEvent ){
				fetchEvent();
			}
		}, 4000);
	});

})(jQuery);